package com.project.nominee.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.nominee.entity.Nominee;
import com.project.nominee.model.NomineeModel;
import com.project.nominee.repository.NomineeRepository;
import com.project.nominee.util.Conversion;

@Service
public class NomineeServiceImpl implements NomineeService {

	@Autowired
	private NomineeRepository nomineeRepository;
	@Autowired
	private Conversion conversion;
	/******************************************
	 - Method Name      : saveNominee
	 - Input Parameters : NomineeModel nomineeModel
	 - Return type      : NomineeModel
	 - Author           : Pamireddy Sai Vikas Reddy
	 - Creation Date    : 06-03-2022
	 - Description      : Inserting the nominee information entered by customer  into  the database.
	  ******************************************/
	
	@Override
	public NomineeModel saveNominee(NomineeModel nomineeModel) {
		// TODO Auto-generated method stub
		Nominee newNominee=nomineeRepository.save(conversion.modelToEntity(nomineeModel));
			
		
		
		
		return conversion.entityToModel(newNominee);
	}
	
	
}
