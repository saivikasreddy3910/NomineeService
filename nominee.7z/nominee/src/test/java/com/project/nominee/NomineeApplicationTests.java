package com.project.nominee;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NomineeApplicationTests {

	@Test
	void contextLoads() {
		assertTrue(true);
	}

}
